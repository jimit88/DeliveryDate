var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Jimit_Shippingdate/js/model/shipping-save-processor/default'
        }
    }
};